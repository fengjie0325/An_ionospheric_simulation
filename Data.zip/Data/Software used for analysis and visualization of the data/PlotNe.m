%��TEC��ne
clear all
close all
clc
load T1
load T2
load T3
load T4

load DataMSISIRI 
load DataNeu neNew
load DataDust ndecay
neNew2=neNew;
neNew2(81:221,161:321)=neNew(81:221,161:321)-ndecay;
for i=1:721
    for j=1:401
        if neNew2(i,j)<0
            neNew2(i,j)=0;
        end
    end
end


x1=-200:0;
y1=round(-x1.^2.*7/360-7/3.*x1+300);%�Գ���-60km������370km

% i=1:201;

x2=1:200;
y2=round(-x2.^2.*3/500+6/5.*x2+300);%�Գ���100km������360km
x=[x1 x2];
y=[y1 y2];
% if y1<0
%     y1=0
% end
y(y<80)=80;
Ne=NaN(size(x));
for i=1:401
    Ne(i)=neNew2(z0==y(i),x0==x(i));
end
save Density Ne

subplot(1,2,1);
plot(T1,1:291,'-.r')
hold on
plot(T2,291:-1:221,'-r')
hold on
plot(T3,221:281,'--')
hold on
plot(T4,281:-1:221,':');
% axis([80 300 ]);
xlabel('Oblique TEC/m^2');
ylabel('Altitude/km');
xlabel('x/km')
ylabel('z/km')
%  set(gca,'YLim',[80 300]);
xlabel('Vertical TEC/m^2');
ylabel('Altitude/km');
legend('upleg1','upleg2','downleg1','downleg2')
subplot(1,2,2);
plot(Ne,1:401)
xlabel('Electron Density/m^3');
ylabel('Altitude/km');
plot(Ne(1:141),y(1:141),'-.r')
hold on
plot(Ne(141:201),y(141:201),'-r')
hold on
plot(Ne(201:301),y(201:301),'--')
hold on
plot(Ne(301:401),y(301:401),':')

xlabel('Electron Density/m^3');
ylabel('Altitude/km');
set(gca,'YLim',[80 380]);