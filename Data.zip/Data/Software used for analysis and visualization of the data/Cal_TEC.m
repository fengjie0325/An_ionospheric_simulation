clear all
close all
clc
load DataMSISIRI 
load DataNeu neNew
load DataDust ndecay
neNew2=neNew;
neNew2(81:221,161:321)=neNew(81:221,161:321)-ndecay;
%��80��500����
neNew3=neNew2(1:421,:);
figure
imagesc(x0,z0(1:421),neNew3)
set(gca,'Ydir','Normal')
xlabel('x/km')
ylabel('z/km')
neNew3=neNew3(1:421,1:201);
num=1000;
x1=-200:0;
y1=80:500;
X1=(ones(length(y1),1))*x1;
Y1=y1'*ones(1,length(x1));

load first X01
T1=zeros(1,291);
%����бTEC
% for i=1:296
    for i=1:291
Xi=[linspace(X01(i),0,1000)];
Yi=[linspace(i-1+80,0,1000)];
ne1=interp2(X1,Y1,neNew3,Xi,Yi);
ne1(find(isnan(ne1)))=0;
d=sqrt((Xi(1)/1000)^2+(Yi(1)/1000)^2);
VTEC=1e3*d*sum(ne1);%��λm-2
T1(1,i)=VTEC;
end 
figure
plot(T1,1:291)
save T1
%���㴹ֱTEC
for i=1:296
Xi=[linspace(X01(i),X01(i),1000)];
Yi=[linspace(i-1+80,0,1000)];
% X2=(ones(length(y2),1))*x2;
% Y2=y2'*ones(1,length(x2));
ne1=interp2(X1,Y1,neNew3,Xi,Yi);
ne1(find(isnan(ne1)))=0;% index=find(isnan(ne1)); ne1(index)=0;
d=Yi(1)/1000;
TEC=1e3*d*sum(ne1);
T11(1,i)=TEC;
end 
figure
plot(T11,1:296)
save T11
